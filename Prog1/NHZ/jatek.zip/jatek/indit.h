//
// Created by Jajecnik Marcell on 2022. 11. 12..
//

#ifndef JATEK_INDIT_H
#define JATEK_INDIT_H
#include <stdbool.h>

typedef struct kerdesek {
    int nehezseg;
    char* kerdes;
    char* A;
    char* B;
    char* C;
    char* D;
    char helyes;
    char* kategoria;
}kerdesek;

kerdesek *kerdest_masol(char *sor, kerdesek *kerdesregi, int kerdesekszama);
bool kerdesbetolt(kerdesek* kerdes);
#endif //JATEK_INDIT_H
