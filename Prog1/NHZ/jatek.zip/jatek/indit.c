//
// Created by Jajecnik Marcell on 2022. 11. 12..
//

#include "indit.h"
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <stdlib.h>
#include "debugmalloc.h"

kerdesek* kerdest_masol(char *sor, kerdesek *kerdesregi, int kerdesekszama){
    kerdesek *uj=(kerdesek*) malloc(sizeof(kerdesek)*(kerdesekszama));
    for (int i = 0; i < kerdesekszama; ++i) {
        uj[i].nehezseg=kerdesregi[i].nehezseg;
        strcpy(uj[i].kerdes,kerdesregi[i].kerdes);
        strcpy(uj[i].A,kerdesregi[i].A);
        strcpy(uj[i].B,kerdesregi[i].B);
        strcpy(uj[i].C,kerdesregi[i].C);
        strcpy(uj[i].D,kerdesregi[i].D);
        strcpy(uj[i].helyes,kerdesregi[i].helyes);
        strcpy(uj[i].kategoria,kerdesregi[i].kategoria);
    }
    free(kerdesregi);
    kerdesregi=uj;
    kerdesregi[kerdesekszama+1].nehezseg= strtok(sor,';');
    strcpy(kerdesregi[kerdesekszama+1].kerdes,strtok(NULL,';'));
    strcpy(kerdesregi[kerdesekszama+1].A,strtok(NULL,';'));
    strcpy(kerdesregi[kerdesekszama+1].B,strtok(NULL,';'));
    strcpy(kerdesregi[kerdesekszama+1].C,strtok(NULL,';'));
    strcpy(kerdesregi[kerdesekszama+1].D,strtok(NULL,';'));
    kerdesregi[kerdesekszama+1].helyes=strtok(NULL,';');
    kerdesregi[kerdesekszama+1].kategoria=strtok(NULL,';');

    return kerdesregi;
}

bool kerdesbetolt (kerdesek* kerdes){
    FILE *fp;
    fp= fopen("kerdes.csv","r");
    if (fp==NULL) return false;
    char c_in=NULL;
    int kerdesek_szama=0;
    kerdesek *kerdesbe=(kerdesek*) malloc(sizeof(kerdesek*)*1);
    while (c_in!=EOF){

        int db = 0;
        char *sor = (char*) malloc(sizeof(char) * 1);
        sor[0] = '\0';
        kerdesek_szama++;
        while (c_in != '\n') {
            char ujkar = c_in;
            char *ujtomb = (char *) malloc(sizeof(char) * (db + 1 + 1));
            for (int i = 0; i < db; ++i)
                ujtomb[i] = sor[i];
            free(sor);
            sor = ujtomb;
            ujtomb[db] = ujkar;
            ujtomb[db + 1] = '\0';
            ++db;
            c_in = fgetc(fp);
//                fscanf(fp,"s",c_in);
            printf("%c",c_in);
        }

//            char *token = strtok(sor, ";");
        kerdest_masol(&sor, &kerdesbe, kerdesek_szama);
//        free(sor);

//        c_in=fgetc(fp);
//        fscanf(fp,"s",c_in);

        printf("%d",kerdesek_szama);
    }
    kerdes=kerdesbe;
    printf("%d",kerdesek_szama);
    free(kerdesbe);
    free(kerdesbe->kerdes);
    free(kerdesbe->A);
    free(kerdesbe->B);
    free(kerdesbe->C);
    free(kerdesbe->D);
    free(kerdesbe->kategoria);
    fclose(fp);
    return true;
}