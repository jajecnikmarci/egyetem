var searchData=
[
  ['kerdesek_0',['kerdesek',['../structkerdesek.html',1,'']]]
];
