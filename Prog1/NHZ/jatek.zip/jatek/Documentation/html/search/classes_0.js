var searchData=
[
  ['debugmallocdata_0',['DebugmallocData',['../struct_debugmalloc_data.html',1,'']]],
  ['debugmallocentry_1',['DebugmallocEntry',['../struct_debugmalloc_entry.html',1,'']]]
];
