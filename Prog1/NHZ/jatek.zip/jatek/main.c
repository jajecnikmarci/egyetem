#include "indit.h"
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <stdlib.h>
#include "debugmalloc.h"

int main() {
    kerdesek *kerdes;
    if(kerdesbetolt(&kerdes)) printf("Kérdések betöltve\n");
    printf("%s", kerdes[21].A);
    printf("d",kerdes);
    return 0;
}
