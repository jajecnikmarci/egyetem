var searchData=
[
  ['ker_5fcsop_5ftomben_0',['ker_csop_tomben',['../beolvas_8h.html#a4336b5477be572937ae93163b8eb7921',1,'beolvas.h']]],
  ['kerdes_1',['Kerdes',['../beolvas_8h.html#a535c987f47562c33e1e59c6d50cb0aaa',1,'beolvas.h']]]
];
