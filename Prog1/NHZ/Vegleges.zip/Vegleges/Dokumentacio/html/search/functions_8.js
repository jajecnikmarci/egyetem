var searchData=
[
  ['token_0',['token',['../beolvas_8c.html#a0d89848cb479cd1d01dec9e96cdf8697',1,'token(char *sor, char *token_ptrek[]):&#160;beolvas.c'],['../beolvas_8h.html#a0d89848cb479cd1d01dec9e96cdf8697',1,'token(char *sor, char *token_ptrek[]):&#160;beolvas.c']]]
];
