var searchData=
[
  ['tail_0',['tail',['../struct_debugmalloc_data.html#a6a489bd48f708358b171a68acf75de9f',1,'DebugmallocData']]]
];
