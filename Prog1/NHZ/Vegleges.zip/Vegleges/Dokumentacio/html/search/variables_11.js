var searchData=
[
  ['user_5fmem_0',['user_mem',['../struct_debugmalloc_entry.html#a20cf96b6c21400f0123a6a3b6dae9876',1,'DebugmallocEntry']]]
];
