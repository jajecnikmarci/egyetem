var searchData=
[
  ['max_5fblock_5fsize_0',['max_block_size',['../struct_debugmalloc_data.html#a5ff6535cb48e89d8b0707e889ba72b0d',1,'DebugmallocData']]],
  ['megvalaszolt_1',['megvalaszolt',['../struct_eredmeny.html#a05caadba6f41e9f5e13409c3fb881c5e',1,'Eredmeny']]]
];
