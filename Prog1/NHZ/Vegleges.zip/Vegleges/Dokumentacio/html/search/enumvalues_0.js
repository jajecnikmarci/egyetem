var searchData=
[
  ['debugmalloc_5fcanary_5fchar_0',['debugmalloc_canary_char',['../debugmalloc_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba8e3d5ad8628140edd887b8920f521cfd',1,'debugmalloc.h']]],
  ['debugmalloc_5fcanary_5fsize_1',['debugmalloc_canary_size',['../debugmalloc_8h.html#a06fc87d81c62e9abb8790b6e5713c55bab345007cf28a2516c0ba24371a400520',1,'debugmalloc.h']]],
  ['debugmalloc_5fmax_5fblock_5fsize_5fdefault_2',['debugmalloc_max_block_size_default',['../debugmalloc_8h.html#a06fc87d81c62e9abb8790b6e5713c55bae8726dfde3f35d4345009234ee734f6c',1,'debugmalloc.h']]],
  ['debugmalloc_5ftablesize_3',['debugmalloc_tablesize',['../debugmalloc_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba40803f0d5a26a349a78cbd998cb8a2a1',1,'debugmalloc.h']]]
];
