var searchData=
[
  ['line_0',['line',['../struct_debugmalloc_entry.html#a05ef0c4dbeec4fc8ccb225de9c26d896',1,'DebugmallocEntry']]],
  ['logfile_1',['logfile',['../struct_debugmalloc_data.html#af5ff893eedb28514f6f69c3687ca893b',1,'DebugmallocData']]]
];
