var searchData=
[
  ['kategoria_0',['kategoria',['../struct_kerdes.html#a60e60f9e02b3c277b720692c53a7fbb7',1,'Kerdes::kategoria()'],['../structker__csop__tomben.html#a60e60f9e02b3c277b720692c53a7fbb7',1,'ker_csop_tomben::kategoria()']]],
  ['ker_5fcsop_5ftomben_1',['ker_csop_tomben',['../structker__csop__tomben.html',1,'ker_csop_tomben'],['../beolvas_8h.html#a4336b5477be572937ae93163b8eb7921',1,'ker_csop_tomben():&#160;beolvas.h']]],
  ['kerdes_2',['Kerdes',['../struct_kerdes.html',1,'']]],
  ['kerdes_3',['kerdes',['../struct_kerdes.html#a80b9412c87430e513ec2e0ab194e5765',1,'Kerdes::kerdes()'],['../structker__csop__tomben.html#a80b9412c87430e513ec2e0ab194e5765',1,'ker_csop_tomben::kerdes()']]],
  ['kerdes_4',['Kerdes',['../beolvas_8h.html#a535c987f47562c33e1e59c6d50cb0aaa',1,'beolvas.h']]],
  ['kerdes_5ffelteves_5',['kerdes_felteves',['../jatek_8c.html#aacf43817bf40c738a1ad02a58995d45f',1,'kerdes_felteves(ker_csop_tomben *kerdesektarhaza[], int kerdesek_csoportositva[], int nehezsegi_szint):&#160;jatek.c'],['../jatek_8h.html#aacf43817bf40c738a1ad02a58995d45f',1,'kerdes_felteves(ker_csop_tomben *kerdesektarhaza[], int kerdesek_csoportositva[], int nehezsegi_szint):&#160;jatek.c']]],
  ['kerdeseket_5ffelszabadit_6',['kerdeseket_felszabadit',['../beolvas_8c.html#ab4e72ef8d466b9bbcd18eb534e05c141',1,'kerdeseket_felszabadit(ker_csop_tomben **kerdesek, int *kerdesek_csoportositva, int nehezsegfajtak):&#160;beolvas.c'],['../beolvas_8h.html#ab4e72ef8d466b9bbcd18eb534e05c141',1,'kerdeseket_felszabadit(ker_csop_tomben **kerdesek, int *kerdesek_csoportositva, int nehezsegfajtak):&#160;beolvas.c']]],
  ['kerdest_5fbeszur_7',['kerdest_beszur',['../beolvas_8c.html#ab594ffb71c9823ba35b87d4842172bb3',1,'kerdest_beszur(Kerdes **peleje):&#160;beolvas.c'],['../beolvas_8h.html#ab594ffb71c9823ba35b87d4842172bb3',1,'kerdest_beszur(Kerdes **peleje):&#160;beolvas.c']]],
  ['kerdest_5fcsoportosit_8',['kerdest_csoportosit',['../beolvas_8c.html#aea0b000c67a3937d39288473b771d86b',1,'kerdest_csoportosit(Kerdes *kerdesek, int **kerdesek_csoportositva):&#160;beolvas.c'],['../beolvas_8h.html#aea0b000c67a3937d39288473b771d86b',1,'kerdest_csoportosit(Kerdes *kerdesek, int **kerdesek_csoportositva):&#160;beolvas.c']]],
  ['kivant_5fnehezsegi_5fszint_9',['kivant_nehezsegi_szint',['../jatek_8c.html#a9277a4a90e115c7b8b567b84c5ef1688',1,'kivant_nehezsegi_szint(int kerdesek_csoportositva[], int nehezsegfajtak):&#160;jatek.c'],['../jatek_8h.html#a9277a4a90e115c7b8b567b84c5ef1688',1,'kivant_nehezsegi_szint(int kerdesek_csoportositva[], int nehezsegfajtak):&#160;jatek.c']]],
  ['konvertal_10',['konvertal',['../beolvas_8c.html#aee3cca7e0b7c5495b9bbd22e597a4565',1,'konvertal(Kerdes *kerdes):&#160;beolvas.c'],['../beolvas_8h.html#aee3cca7e0b7c5495b9bbd22e597a4565',1,'konvertal(Kerdes *kerdes):&#160;beolvas.c']]],
  ['kov_11',['kov',['../struct_kerdes.html#a5782d2bc57a1125739c418c2c682f7bf',1,'Kerdes']]]
];
