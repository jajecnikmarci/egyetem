var searchData=
[
  ['c_0',['c',['../struct_kerdes.html#a9df78bd38aa81763ad1c56f3de8d5d3e',1,'Kerdes::c()'],['../structker__csop__tomben.html#a9df78bd38aa81763ad1c56f3de8d5d3e',1,'ker_csop_tomben::c()']]],
  ['calloc_1',['calloc',['../debugmalloc_8h.html#ac07b71d27b6b37e81ac3a4c230f5794e',1,'debugmalloc.h']]],
  ['csop_5ftomb_5fbelerak_2',['csop_tomb_belerak',['../beolvas_8c.html#a5168173497a2b8c4f6f28d6a4d237364',1,'csop_tomb_belerak(Kerdes *kerdesek_lancoltban, int nehezsegfajtak, int *kerdesek_csoportositva):&#160;beolvas.c'],['../beolvas_8h.html#ac4e5fac28c72baadcfa9ab06fd297dc7',1,'csop_tomb_belerak(Kerdes *kerdesek_lacoltban, int nehezsegfajtak, int *kerdesek_csoportositva):&#160;beolvas.c']]]
];
