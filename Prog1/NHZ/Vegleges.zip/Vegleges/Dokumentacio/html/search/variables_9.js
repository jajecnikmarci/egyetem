var searchData=
[
  ['kategoria_0',['kategoria',['../struct_kerdes.html#a60e60f9e02b3c277b720692c53a7fbb7',1,'Kerdes::kategoria()'],['../structker__csop__tomben.html#a60e60f9e02b3c277b720692c53a7fbb7',1,'ker_csop_tomben::kategoria()']]],
  ['kerdes_1',['kerdes',['../struct_kerdes.html#a80b9412c87430e513ec2e0ab194e5765',1,'Kerdes::kerdes()'],['../structker__csop__tomben.html#a80b9412c87430e513ec2e0ab194e5765',1,'ker_csop_tomben::kerdes()']]],
  ['kov_2',['kov',['../struct_kerdes.html#a5782d2bc57a1125739c418c2c682f7bf',1,'Kerdes']]]
];
