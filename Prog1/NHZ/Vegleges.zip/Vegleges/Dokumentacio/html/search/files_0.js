var searchData=
[
  ['beolvas_2ec_0',['beolvas.c',['../beolvas_8c.html',1,'']]],
  ['beolvas_2eh_1',['beolvas.h',['../beolvas_8h.html',1,'']]]
];
