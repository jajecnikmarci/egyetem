var searchData=
[
  ['nehezseg_0',['nehezseg',['../struct_kerdes.html#a6f7594f0e86899840759e912e694c869',1,'Kerdes']]],
  ['nehezsegeket_5fszamol_1',['nehezsegeket_szamol',['../beolvas_8c.html#acc8e53f23b54287c14f939d3a20bf6ee',1,'nehezsegeket_szamol(Kerdes *eleje, int *nehezsegfajtakszama):&#160;beolvas.c'],['../beolvas_8h.html#acc8e53f23b54287c14f939d3a20bf6ee',1,'nehezsegeket_szamol(Kerdes *eleje, int *nehezsegfajtakszama):&#160;beolvas.c']]],
  ['next_2',['next',['../struct_debugmalloc_entry.html#a7ebf7cb15f24577c59e05768d8f9ffc5',1,'DebugmallocEntry']]]
];
