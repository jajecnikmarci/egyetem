var searchData=
[
  ['beolvas_0',['beolvas',['../beolvas_8c.html#a0d57e08bca0219f65eb7b01ef1b0846c',1,'beolvas(Kerdes *kerdes, FILE *f):&#160;beolvas.c'],['../beolvas_8h.html#a0d57e08bca0219f65eb7b01ef1b0846c',1,'beolvas(Kerdes *kerdes, FILE *f):&#160;beolvas.c']]]
];
