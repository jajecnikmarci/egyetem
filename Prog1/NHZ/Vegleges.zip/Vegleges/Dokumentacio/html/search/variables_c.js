var searchData=
[
  ['nehezseg_0',['nehezseg',['../struct_kerdes.html#a6f7594f0e86899840759e912e694c869',1,'Kerdes']]],
  ['next_1',['next',['../struct_debugmalloc_entry.html#a7ebf7cb15f24577c59e05768d8f9ffc5',1,'DebugmallocEntry']]]
];
