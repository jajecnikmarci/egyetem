var searchData=
[
  ['real_5fmem_0',['real_mem',['../struct_debugmalloc_entry.html#ae241706d126e0114e48ce7c4083d93d1',1,'DebugmallocEntry']]],
  ['realloc_1',['realloc',['../debugmalloc_8h.html#a54df243d89c451240697d7d3afb5663f',1,'debugmalloc.h']]]
];
