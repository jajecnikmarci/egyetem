var searchData=
[
  ['jatekosnev_0',['jatekosnev',['../struct_eredmeny.html#a998594565b609f6df42f959408aa6eff',1,'Eredmeny']]]
];
