var searchData=
[
  ['tail_0',['tail',['../struct_debugmalloc_data.html#a6a489bd48f708358b171a68acf75de9f',1,'DebugmallocData']]],
  ['token_1',['token',['../beolvas_8c.html#a0d89848cb479cd1d01dec9e96cdf8697',1,'token(char *sor, char *token_ptrek[]):&#160;beolvas.c'],['../beolvas_8h.html#a0d89848cb479cd1d01dec9e96cdf8697',1,'token(char *sor, char *token_ptrek[]):&#160;beolvas.c']]]
];
