var searchData=
[
  ['csop_5ftomb_5fbelerak_0',['csop_tomb_belerak',['../beolvas_8c.html#a5168173497a2b8c4f6f28d6a4d237364',1,'csop_tomb_belerak(Kerdes *kerdesek_lancoltban, int nehezsegfajtak, int *kerdesek_csoportositva):&#160;beolvas.c'],['../beolvas_8h.html#ac4e5fac28c72baadcfa9ab06fd297dc7',1,'csop_tomb_belerak(Kerdes *kerdesek_lacoltban, int nehezsegfajtak, int *kerdesek_csoportositva):&#160;beolvas.c']]]
];
