var searchData=
[
  ['file_0',['file',['../struct_debugmalloc_entry.html#a353d29f9f9cc0db6fca9d49b5f88d34d',1,'DebugmallocEntry']]],
  ['func_1',['func',['../struct_debugmalloc_entry.html#ac8a2334cf5c64b1f708ced23ef569db4',1,'DebugmallocEntry']]]
];
