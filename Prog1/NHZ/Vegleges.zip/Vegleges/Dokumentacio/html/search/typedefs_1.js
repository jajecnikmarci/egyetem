var searchData=
[
  ['eredmeny_0',['Eredmeny',['../dicsoseglista_8h.html#a35c6cb0d490612e6045c1a108dc40d21',1,'dicsoseglista.h']]]
];
