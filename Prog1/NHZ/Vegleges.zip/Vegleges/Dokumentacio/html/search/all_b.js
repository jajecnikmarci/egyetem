var searchData=
[
  ['main_0',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.c']]],
  ['main_2ec_1',['main.c',['../main_8c.html',1,'']]],
  ['malloc_2',['malloc',['../debugmalloc_8h.html#a535b58ab5aa48e2e86073e334d43fd32',1,'debugmalloc.h']]],
  ['max_5fblock_5fsize_3',['max_block_size',['../struct_debugmalloc_data.html#a5ff6535cb48e89d8b0707e889ba72b0d',1,'DebugmallocData']]],
  ['megvalaszolt_4',['megvalaszolt',['../struct_eredmeny.html#a05caadba6f41e9f5e13409c3fb881c5e',1,'Eredmeny']]]
];
