var searchData=
[
  ['eredmeny_0',['Eredmeny',['../struct_eredmeny.html',1,'']]]
];
