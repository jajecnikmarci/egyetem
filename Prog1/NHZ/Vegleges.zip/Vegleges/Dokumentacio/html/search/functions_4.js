var searchData=
[
  ['lancoltbaolvas_0',['lancoltbaolvas',['../beolvas_8c.html#a0d342e6f077337002b1015d9adaa4916',1,'lancoltbaolvas(Kerdes **kerdesek_eredeti):&#160;beolvas.c'],['../beolvas_8h.html#a0d342e6f077337002b1015d9adaa4916',1,'lancoltbaolvas(Kerdes **kerdesek_eredeti):&#160;beolvas.c']]]
];
