var searchData=
[
  ['debugmalloc_2eh_0',['debugmalloc.h',['../debugmalloc_8h.html',1,'']]],
  ['dicsoseglista_2ec_1',['dicsoseglista.c',['../dicsoseglista_8c.html',1,'']]],
  ['dicsoseglista_2eh_2',['dicsoseglista.h',['../dicsoseglista_8h.html',1,'']]]
];
