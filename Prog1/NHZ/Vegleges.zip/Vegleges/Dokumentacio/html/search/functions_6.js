var searchData=
[
  ['nehezsegeket_5fszamol_0',['nehezsegeket_szamol',['../beolvas_8c.html#acc8e53f23b54287c14f939d3a20bf6ee',1,'nehezsegeket_szamol(Kerdes *eleje, int *nehezsegfajtakszama):&#160;beolvas.c'],['../beolvas_8h.html#acc8e53f23b54287c14f939d3a20bf6ee',1,'nehezsegeket_szamol(Kerdes *eleje, int *nehezsegfajtakszama):&#160;beolvas.c']]]
];
