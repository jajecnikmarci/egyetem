var searchData=
[
  ['ido_0',['ido',['../struct_eredmeny.html#a11b0e07027a04b6c3140254942b8f030',1,'Eredmeny']]]
];
