var searchData=
[
  ['segitseg_5fkeres_0',['segitseg_keres',['../jatek_8c.html#a66d6fb54d1cc31df76d4817c6e1bd378',1,'segitseg_keres(ker_csop_tomben kerdes, bool *felezes_hasznaltsag, bool *kozonseg_szavazata_hasznaltsag):&#160;jatek.c'],['../jatek_8h.html#a66d6fb54d1cc31df76d4817c6e1bd378',1,'segitseg_keres(ker_csop_tomben kerdes, bool *felezes_hasznaltsag, bool *kozonseg_szavazata_hasznaltsag):&#160;jatek.c']]],
  ['sor_5fbe_1',['sor_be',['../beolvas_8c.html#ab720d1d0e6867b8ccc60f4f0205dc206',1,'sor_be(FILE *f):&#160;beolvas.c'],['../beolvas_8h.html#ab720d1d0e6867b8ccc60f4f0205dc206',1,'sor_be(FILE *f):&#160;beolvas.c']]]
];
