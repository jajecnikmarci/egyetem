var searchData=
[
  ['lancoltbaolvas_0',['lancoltbaolvas',['../beolvas_8c.html#a0d342e6f077337002b1015d9adaa4916',1,'lancoltbaolvas(Kerdes **kerdesek_eredeti):&#160;beolvas.c'],['../beolvas_8h.html#a0d342e6f077337002b1015d9adaa4916',1,'lancoltbaolvas(Kerdes **kerdesek_eredeti):&#160;beolvas.c']]],
  ['line_1',['line',['../struct_debugmalloc_entry.html#a05ef0c4dbeec4fc8ccb225de9c26d896',1,'DebugmallocEntry']]],
  ['logfile_2',['logfile',['../struct_debugmalloc_data.html#af5ff893eedb28514f6f69c3687ca893b',1,'DebugmallocData']]]
];
