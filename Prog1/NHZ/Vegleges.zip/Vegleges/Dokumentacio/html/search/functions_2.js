var searchData=
[
  ['dicsoseglistat_5fkezel_0',['dicsoseglistat_kezel',['../dicsoseglista_8c.html#a0c18fb8e3f059d3ead8b0abee0321f2f',1,'dicsoseglistat_kezel(Eredmeny eredmeny, int nehezsegiszint, int nyeremenyek[]):&#160;dicsoseglista.c'],['../dicsoseglista_8h.html#a0c18fb8e3f059d3ead8b0abee0321f2f',1,'dicsoseglistat_kezel(Eredmeny eredmeny, int nehezsegiszint, int nyeremenyek[]):&#160;dicsoseglista.c']]]
];
