var searchData=
[
  ['valasz_5fbeker_0',['valasz_beker',['../jatek_8c.html#a9a4f7307dee2c276a0facc89751f248e',1,'valasz_beker(ker_csop_tomben kerdes):&#160;jatek.c'],['../jatek_8h.html#a9a4f7307dee2c276a0facc89751f248e',1,'valasz_beker(ker_csop_tomben kerdes):&#160;jatek.c']]]
];
