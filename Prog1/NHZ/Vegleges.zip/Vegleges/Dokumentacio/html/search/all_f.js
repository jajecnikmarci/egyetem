var searchData=
[
  ['segitseg_5fkeres_0',['segitseg_keres',['../jatek_8c.html#a66d6fb54d1cc31df76d4817c6e1bd378',1,'segitseg_keres(ker_csop_tomben kerdes, bool *felezes_hasznaltsag, bool *kozonseg_szavazata_hasznaltsag):&#160;jatek.c'],['../jatek_8h.html#a66d6fb54d1cc31df76d4817c6e1bd378',1,'segitseg_keres(ker_csop_tomben kerdes, bool *felezes_hasznaltsag, bool *kozonseg_szavazata_hasznaltsag):&#160;jatek.c']]],
  ['size_1',['size',['../struct_debugmalloc_entry.html#a854352f53b148adc24983a58a1866d66',1,'DebugmallocEntry']]],
  ['sor_5fbe_2',['sor_be',['../beolvas_8c.html#ab720d1d0e6867b8ccc60f4f0205dc206',1,'sor_be(FILE *f):&#160;beolvas.c'],['../beolvas_8h.html#ab720d1d0e6867b8ccc60f4f0205dc206',1,'sor_be(FILE *f):&#160;beolvas.c']]]
];
