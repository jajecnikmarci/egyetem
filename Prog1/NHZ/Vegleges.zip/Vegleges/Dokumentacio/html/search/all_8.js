var searchData=
[
  ['jatek_2ec_0',['jatek.c',['../jatek_8c.html',1,'']]],
  ['jatek_2eh_1',['jatek.h',['../jatek_8h.html',1,'']]],
  ['jatekosnev_2',['jatekosnev',['../struct_eredmeny.html#a998594565b609f6df42f959408aa6eff',1,'Eredmeny']]]
];
