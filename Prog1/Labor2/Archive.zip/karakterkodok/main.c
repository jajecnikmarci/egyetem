#include <stdio.h>

int main() {
    char betu;
    while (scanf("%c",&betu)==1){
        printf("betu='%c', betu=%d\n", betu,betu);
    }
    return 0;
}
