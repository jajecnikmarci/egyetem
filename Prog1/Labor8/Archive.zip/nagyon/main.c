#include <stdio.h>
#include "debugmalloc.h"

int main() {
    char *t=(char*) 
    return 0;
}
