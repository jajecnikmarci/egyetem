#include <stdio.h>

int main() {
//    int i =1;
//    while (i<=20){
//        printf("%d\n",i);
//        i=i+1;
//    }
    for(int i=1;i<=20;i=i+1){
        printf("%d\n",i);
    }
    return 0;
}
