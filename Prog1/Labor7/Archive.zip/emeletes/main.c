#include <stdio.h>

int main() {
    double a= (4.0+2.0-(3.0-(6.0+(4.0/5.0))))/(3.0*(2.0-7.0));
    printf("%f", a);
    return 0;
}
